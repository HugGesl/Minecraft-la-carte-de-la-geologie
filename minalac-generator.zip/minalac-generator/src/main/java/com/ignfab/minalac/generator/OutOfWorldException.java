package com.ignfab.minalac.generator;

public class OutOfWorldException extends Exception {
}