package com.ignfab.minalac.generator;

public enum SemanticType {
    Grass, Stone, Air, Water, Dirt
}